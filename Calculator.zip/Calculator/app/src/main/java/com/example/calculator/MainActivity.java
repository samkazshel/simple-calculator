package com.example.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    EditText input;
    double num1 = 0;
    double num2 = 0;
    char operation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.editText);

    }

    public void operator_OnClick(View v){
        Button op = (Button) v;
        operation = op.getText().charAt(0);
        num1 = Double.valueOf(String.valueOf(input.getText()));
        input.setText("");
    }

    public void eqlOnClick(View V){
        num2 = Double.valueOf(String.valueOf(input.getText()));

        if (operation == '+'){
            input.setText(String.valueOf(num1+num2));
        }

        if (operation == '-'){
            input.setText(String.valueOf(num1-num2));
        }

        if (operation == 'x'){
            input.setText(String.valueOf(num1*num2));
        }

        if (operation == '÷'){
            input.setText(String.valueOf(num1/num2));
        }
    }

    public void operationClear(View V){
        num1 = 0;
        num2 = 0;
        input.setText("");
    }


}